import DrawFlow from "./src/DrawFlow";
/* istanbul ignore next */
DrawFlow.install = function(Vue) {
  Vue.component(DrawFlow.name, DrawFlow);
};
export default DrawFlow;
