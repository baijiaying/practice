class areaData {
  constructor() {
    return [
      {
        areaName: "西城区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "朝阳区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "300"
          }
        ]
      },
      {
        areaName: "丰台区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "石景山区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "海淀区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "门头沟区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "房山区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "通州区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "90"
          },
          {
            title: "标题3",
            value: "80"
          }
        ]
      },
      {
        areaName: "顺义区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "昌平区",
        DateItems: [
          {
            title: "标题1",
            value: "40"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "13  0"
          }
        ]
      },
      {
        areaName: "怀柔区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "平谷区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "密云区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "大兴区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      },
      {
        areaName: "延庆区",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      }
    ];
  }
}
export default areaData;
