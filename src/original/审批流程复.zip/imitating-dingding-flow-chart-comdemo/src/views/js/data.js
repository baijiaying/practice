class areaData {
  constructor() {
    return [
      {
        areaName: "丰县",
        DateItems: [
          {
            title: "标题1",
            value: "10"
          },
          {
            title: "标题2",
            value: "20"
          },
          {
            title: "标题3",
            value: "30"
          }
        ]
      }
    ];
  }
}
export default areaData;
