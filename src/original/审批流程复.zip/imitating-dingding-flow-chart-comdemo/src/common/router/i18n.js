module.exports = {
  messages: {
    CN: {
      home: { name: "首页" }
    },
    US: {
      home: { name: "home" }
    },
    HK: {
      home: { name: "首頁" }
    }
  }
};
