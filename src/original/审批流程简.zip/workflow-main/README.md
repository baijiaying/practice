# work-flow

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

## 效果图

![](https://img-blog.csdnimg.cn/a057463383c242489e0e523673f91d1b.png?x-ossprocess=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl80MzM2Mzg3MQ==,size_16,color_FFFFFF,t_70)

## [CSDN浏览](https://blog.csdn.net/weixin_43363871/article/details/119142248?spm=1001.2014.3001.5501)：https://blog.csdn.net/weixin_43363871/article/details/119142248?spm=1001.2014.3001.5501

#### 有问题欢迎在Issues里面讨论
